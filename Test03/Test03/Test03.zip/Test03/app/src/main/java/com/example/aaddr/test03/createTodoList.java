package com.example.aaddr.test03;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class createTodoList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_todo_list);
    }
}
